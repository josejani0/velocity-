let map = L.map('map').setView([10.8505, 76.2711], 7); // Kerala Center

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

let startMarker, endMarker, routingControl;

function searchAndCalculate() {
  const startPlace = document.getElementById('start').value;
  const endPlace = document.getElementById('end').value;

  if (!startPlace || !endPlace) {
    alert('Please enter both start and end locations.');
    return;
  }

  geocodePlace(startPlace, function(startCoords) {
    geocodePlace(endPlace, function(endCoords) {
      if (!isInsideKerala(startCoords.lat, startCoords.lng) || !isInsideKerala(endCoords.lat, endCoords.lng)) {
        alert("Service outside Kerala is not provided.");
        return;
      }

      if (startMarker) map.removeLayer(startMarker);
      if (endMarker) map.removeLayer(endMarker);
      if (routingControl) map.removeControl(routingControl);

      startMarker = addMarker(startCoords.lat, startCoords.lng, "Start");
      endMarker = addMarker(endCoords.lat, endCoords.lng, "End");

      drawRoute(startCoords, endCoords);

      const resultCard = document.getElementById('result-card');
      resultCard.classList.remove('hidden');
      setTimeout(() => resultCard.classList.add('show'), 50);
    });
  });
}

function geocodePlace(place, callback) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(place + ', Kerala')}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      if (data && data.length > 0) {
        callback({ lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) });
      } else {
        alert('Location not found.');
      }
    })
    .catch(error => {
      console.error('Geocoding error:', error);
      alert('Error fetching location data.');
    });
}

function addMarker(lat, lng, label) {
  return L.marker([lat, lng]).addTo(map).bindPopup(label).openPopup();
}

function drawRoute(startCoords, endCoords) {
  routingControl = L.Routing.control({
    waypoints: [
      L.latLng(startCoords.lat, startCoords.lng),
      L.latLng(endCoords.lat, endCoords.lng)
    ],
    routeWhileDragging: false,
    fitSelectedRoutes: true // Auto-zoom to route
  }).on('routesfound', function(e) {
    const routes = e.routes;
    const distanceInKm = (routes[0].summary.totalDistance / 1000).toFixed(2);
    const timeInMinutes = Math.round(routes[0].summary.totalTime / 60);
    const persons = parseInt(document.getElementById('persons').value) || 1;
    const carType = document.getElementById('car-type').value;
    
    // Updated (Lower) Fare Calculation
    const pricePerKm = {
      "Swift": 10,
      "Innova": 12,
      "Seltos": 12,
      "Ertiga": 15,
      "Verna": 15
    }[carType] || 10;

    const price = Math.round(distanceInKm * pricePerKm * persons);

    document.getElementById('distance').innerText = distanceInKm;
    document.getElementById('duration').innerText = `Duration: ${formatTime(timeInMinutes)}`;
    document.getElementById('price').innerText = price;
    document.getElementById('persons-display').innerText = persons;
    document.getElementById('car-selected').innerText = `Car Type: ${carType}`;
  }).addTo(map);
}

function formatTime(minutes) {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours > 0 ? hours + ' hr ' : ''}${mins} min`;
}

function isInsideKerala(lat, lng) {
  return lat >= 8.17 && lat <= 12.97 && lng >= 74.86 && lng <= 77.71;
}

window.addEventListener('load', () => {
  document.getElementById('loader').style.display = 'none';
});